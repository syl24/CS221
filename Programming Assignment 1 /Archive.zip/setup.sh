apt-get install -y libc++abi-dev
apt-get install -y libc++-dev
apt-get install -y make
#apt-get install -y expect
apt-get install -y clang-5.0
apt-get install -y python2.7

ln -s /usr/bin/clang++-5.0 /usr/bin/clang++

